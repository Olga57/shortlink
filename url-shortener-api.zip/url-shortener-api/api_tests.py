#!/usr/bin/env python3
"""
Автоматизированное тестирование REST API сервиса сокращения URL-адресов.
Для корректной работы необходимо запустить сервис на http://localhost:8000
"""

import requests
import json
import random
import string
import time
import logging
import sys

# Конфигурация системы логирования
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("api_tests")

BASE_URL = "http://localhost:8000"


def log_request_response(method, url, response, **kwargs):
    """Вывод информации о запросах и ответах в лог"""
    req_body = kwargs.get('json') or kwargs.get('data') or ""
    req_headers = kwargs.get('headers') or {}
    
    logger.info(f"REQUEST: {method} {url}")
    if req_headers:
        logger.info(f"REQUEST HEADERS: {json.dumps(req_headers)}")
    if req_body:
        logger.info(f"REQUEST BODY: {json.dumps(req_body) if isinstance(req_body, dict) else str(req_body)}")
    
    logger.info(f"RESPONSE STATUS: {response.status_code}")
    try:
        logger.info(f"RESPONSE BODY: {json.dumps(response.json(), indent=2)}")
    except:
        logger.info(f"RESPONSE BODY: {response.text[:200]}")


def test_base_endpoint():
    """Проверка доступности базового эндпоинта"""
    logger.info("==== ТЕСТ: Корневой эндпоинт ====")
    
    response = requests.get(f"{BASE_URL}/")
    log_request_response("GET", f"{BASE_URL}/", response)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert "message" in response.json(), "В ответе отсутствует поле 'message'"
    assert "Добро пожаловать" in response.json()["message"], "Неверное сообщение в ответе"
    
    logger.info("✅ Тест корневого эндпоинта пройден")


def test_shorten_link():
    """Проверка функционала создания сокращенной ссылки"""
    logger.info("==== ТЕСТ: Создание короткой ссылки ====")
    
    payload = {
        "original_url": f"https://example.com/test/{random.randint(1, 10000)}"
    }
    response = requests.post(f"{BASE_URL}/links/shorten", json=payload)
    log_request_response("POST", f"{BASE_URL}/links/shorten", response, json=payload)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert "short_code" in response.json(), "В ответе отсутствует поле 'short_code'"
    assert "original_url" in response.json(), "В ответе отсутствует поле 'original_url'"
    assert payload["original_url"] == response.json()["original_url"], "URL в ответе не соответствует отправленному"
    
    logger.info("✅ Тест создания короткой ссылки пройден")
    return response.json()["short_code"]


def test_custom_link():
    """Проверка создания ссылки с пользовательским алиасом"""
    logger.info("==== ТЕСТ: Создание ссылки с кастомным кодом ====")
    
    custom_code = ''.join(random.choices(string.ascii_lowercase, k=6))
    payload = {
        "original_url": f"https://example.com/custom/{random.randint(1, 10000)}",
        "custom_alias": custom_code
    }
    response = requests.post(f"{BASE_URL}/links/shorten", json=payload)
    log_request_response("POST", f"{BASE_URL}/links/shorten", response, json=payload)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert response.json()["short_code"] == custom_code, f"Полученный код '{response.json()['short_code']}' не соответствует запрошенному '{custom_code}'"
    
    logger.info("✅ Тест создания ссылки с кастомным кодом пройден")
    return custom_code


def test_redirect():
    """Проверка механизма перенаправления по короткой ссылке"""
    logger.info("==== ТЕСТ: Перенаправление по короткой ссылке ====")
    
    short_code = test_shorten_link()
    logger.info(f"Тестирование перенаправления для кода: {short_code}")
    
    response = requests.get(f"{BASE_URL}/{short_code}", allow_redirects=False)
    log_request_response("GET", f"{BASE_URL}/{short_code}", response)
    
    assert response.status_code == 307, f"Ожидался статус 307 (Temporary Redirect), получен {response.status_code}"
    assert 'Location' in response.headers, "В заголовках ответа отсутствует 'Location'"
    logger.info(f"Перенаправление на: {response.headers.get('Location')}")
    
    logger.info("✅ Тест перенаправления пройден")


def test_link_stats():
    """Проверка функционала сбора и отображения статистики переходов"""
    logger.info("==== ТЕСТ: Статистика ссылки ====")
    
    short_code = test_shorten_link()
    logger.info(f"Создана тестовая ссылка с кодом: {short_code}")
    
    # Имитируем переход для увеличения счетчика
    logger.info(f"Переход по ссылке для увеличения счетчика")
    redirect_response = requests.get(f"{BASE_URL}/{short_code}", allow_redirects=False)
    
    # Запрашиваем статистику
    logger.info(f"Запрос статистики для ссылки: {short_code}")
    response = requests.get(f"{BASE_URL}/links/{short_code}/stats")
    log_request_response("GET", f"{BASE_URL}/links/{short_code}/stats", response)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert response.json()["clicks"] >= 1, f"Ожидалось количество кликов >= 1, получено {response.json()['clicks']}"
    assert "last_used_at" in response.json(), "В ответе отсутствует поле 'last_used_at'"
    
    logger.info("✅ Тест статистики ссылки пройден")


def test_link_search():
    """Проверка функционала поиска ссылок"""
    logger.info("==== ТЕСТ: Поиск ссылок ====")
    
    # Создаем уникальную ссылку для тестирования поиска
    unique_str = ''.join(random.choices(string.ascii_lowercase, k=10))
    payload = {
        "original_url": f"https://example.com/{unique_str}"
    }
    logger.info(f"Создаем ссылку с уникальной строкой: {unique_str}")
    create_response = requests.post(f"{BASE_URL}/links/shorten", json=payload)
    log_request_response("POST", f"{BASE_URL}/links/shorten", create_response, json=payload)
    
    # Выполняем поиск
    logger.info(f"Поиск ссылки по строке: {unique_str}")
    response = requests.get(f"{BASE_URL}/links/search?original_url={unique_str}")
    log_request_response("GET", f"{BASE_URL}/links/search?original_url={unique_str}", response)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert len(response.json()) >= 1, f"Ожидался хотя бы 1 результат, получено {len(response.json())}"
    assert unique_str in response.json()[0]["original_url"], f"Строка '{unique_str}' не найдена в результатах поиска"
    
    logger.info("✅ Тест поиска ссылок пройден")


def register_and_login():
    """Тестирование процесса регистрации и аутентификации пользователя"""
    logger.info("==== ТЕСТ: Регистрация и авторизация ====")
    
    # Генерация уникального имени пользователя
    username = f"testuser_{random.randint(10000, 99999)}"
    logger.info(f"Создаем тестового пользователя: {username}")
    
    # Процесс регистрации
    register_payload = {
        "username": username,
        "email": f"{username}@example.com",
        "password": "password123"
    }
    register_response = requests.post(f"{BASE_URL}/register", json=register_payload)
    log_request_response("POST", f"{BASE_URL}/register", register_response, json=register_payload)
    
    if register_response.status_code != 200:
        logger.warning(f"Ошибка регистрации: {register_response.text}")
    
    # Процесс авторизации
    login_data = {"username": username, "password": "password123"}
    logger.info(f"Авторизация пользователя: {username}")
    login_response = requests.post(
        f"{BASE_URL}/token", 
        data=login_data,
        headers={"Content-Type": "application/x-www-form-urlencoded"}
    )
    log_request_response("POST", f"{BASE_URL}/token", login_response, data=login_data)
    
    assert login_response.status_code == 200, f"Ожидался статус 200, получен {login_response.status_code}"
    assert "access_token" in login_response.json(), "В ответе отсутствует access_token"
    
    token = login_response.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    logger.info("✅ Тест регистрации и авторизации пройден")
    return headers


def test_create_project(auth_headers):
    """Проверка создания коллекции для организации ссылок"""
    logger.info("==== ТЕСТ: Создание проекта ====")
    
    payload = {
        "name": f"Test Project {random.randint(1, 1000)}",
        "description": "Тестовый проект для API"
    }
    logger.info(f"Создаем проект: {payload['name']}")
    response = requests.post(f"{BASE_URL}/projects/", json=payload, headers=auth_headers)
    log_request_response("POST", f"{BASE_URL}/projects/", response, json=payload, headers=auth_headers)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert "id" in response.json(), "В ответе отсутствует поле 'id'"
    assert payload["name"] in response.json()["name"], f"Имя проекта в ответе не соответствует отправленному"
    
    logger.info("✅ Тест создания проекта пройден")
    return response.json()["id"]


def test_get_projects(auth_headers):
    """Проверка получения списка коллекций пользователя"""
    logger.info("==== ТЕСТ: Получение списка проектов ====")
    
    # Создаем тестовую коллекцию
    project_id = test_create_project(auth_headers)
    logger.info(f"Создан тестовый проект с ID: {project_id}")
    
    # Получаем список коллекций
    logger.info("Запрашиваем список проектов пользователя")
    response = requests.get(f"{BASE_URL}/projects/", headers=auth_headers)
    log_request_response("GET", f"{BASE_URL}/projects/", response, headers=auth_headers)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert len(response.json()) >= 1, f"Ожидался хотя бы 1 проект, получено {len(response.json())}"
    
    # Проверяем наличие созданной коллекции
    project_found = False
    for project in response.json():
        if project.get("id") == project_id:
            project_found = True
            break
    
    assert project_found, f"Созданный проект с ID {project_id} не найден в списке проектов"
    
    logger.info("✅ Тест получения списка проектов пройден")


def test_update_project(auth_headers):
    """Проверка обновления данных коллекции"""
    logger.info("==== ТЕСТ: Обновление проекта ====")
    
    # Создаем тестовую коллекцию
    project_id = test_create_project(auth_headers)
    logger.info(f"Создан тестовый проект с ID: {project_id}")
    
    # Обновляем данные
    update_payload = {
        "name": f"Updated Project {random.randint(1, 1000)}",
        "description": "Обновленное описание проекта"
    }
    logger.info(f"Обновляем проект {project_id} с данными: {update_payload}")
    response = requests.put(
        f"{BASE_URL}/projects/{project_id}", 
        json=update_payload, 
        headers=auth_headers
    )
    log_request_response("PUT", f"{BASE_URL}/projects/{project_id}", response, json=update_payload, headers=auth_headers)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert update_payload["name"] in response.json()["name"], f"Имя проекта в ответе не соответствует обновленному"
    assert update_payload["description"] in response.json()["description"], f"Описание проекта в ответе не соответствует обновленному"
    
    logger.info("✅ Тест обновления проекта пройден")


def test_link_with_project(auth_headers):
    """Проверка создания ссылки с привязкой к коллекции"""
    logger.info("==== ТЕСТ: Создание ссылки с привязкой к проекту ====")
    
    # Создаем тестовую коллекцию
    project_id = test_create_project(auth_headers)
    logger.info(f"Создан тестовый проект с ID: {project_id}")
    
    # Создаем ссылку с привязкой
    payload = {
        "original_url": f"https://example.com/project-link/{random.randint(1, 10000)}",
        "project_id": project_id
    }
    logger.info(f"Создаем ссылку в проекте {project_id}: {payload}")
    response = requests.post(
        f"{BASE_URL}/links/shorten", 
        json=payload, 
        headers=auth_headers
    )
    log_request_response("POST", f"{BASE_URL}/links/shorten", response, json=payload, headers=auth_headers)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert response.json()["project_id"] == project_id, f"ID проекта в ответе {response.json()['project_id']} не соответствует запрошенному {project_id}"
    
    # Проверяем наличие ссылки в коллекции
    logger.info(f"Проверяем, что ссылка появилась в проекте {project_id}")
    project_response = requests.get(
        f"{BASE_URL}/projects/{project_id}", 
        headers=auth_headers
    )
    log_request_response("GET", f"{BASE_URL}/projects/{project_id}", project_response, headers=auth_headers)
    
    assert project_response.status_code == 200, f"Ожидался статус 200, получен {project_response.status_code}"
    assert len(project_response.json()["links"]) >= 1, f"Ожидалась хотя бы 1 ссылка в проекте, получено {len(project_response.json()['links'])}"
    
    # Проверяем наличие созданной ссылки
    link_found = False
    for link in project_response.json()["links"]:
        if link.get("original_url") == payload["original_url"]:
            link_found = True
            break
    
    assert link_found, f"Созданная ссылка {payload['original_url']} не найдена в проекте"
    
    logger.info("✅ Тест создания ссылки с привязкой к проекту пройден")


def test_link_with_expiry():
    """Проверка функционала временных ссылок с ограниченным сроком действия"""
    logger.info("==== ТЕСТ: Создание ссылки с истечением срока действия ====")
    
    import datetime
    
    # Срок жизни - 1 минута
    expiry_time = (datetime.datetime.now() + datetime.timedelta(minutes=1)).isoformat()
    
    payload = {
        "original_url": f"https://example.com/expiring/{random.randint(1, 10000)}",
        "expires_at": expiry_time
    }
    logger.info(f"Создаем ссылку с истечением срока действия: {payload}")
    response = requests.post(f"{BASE_URL}/links/shorten", json=payload)
    log_request_response("POST", f"{BASE_URL}/links/shorten", response, json=payload)
    
    assert response.status_code == 200, f"Ожидался статус 200, получен {response.status_code}"
    assert "expires_at" in response.json(), "В ответе отсутствует поле 'expires_at'"
    short_code = response.json()["short_code"]
    
    # Проверяем доступность
    logger.info(f"Проверяем, что ссылка {short_code} доступна")
    response = requests.get(f"{BASE_URL}/{short_code}", allow_redirects=False)
    log_request_response("GET", f"{BASE_URL}/{short_code}", response)
    
    assert response.status_code == 307, f"Ожидался статус 307, получен {response.status_code}"
    
    logger.info("✅ Тест создания ссылки с истечением срока действия пройден")
    logger.info("⚠️ Полный тест истечения срока требует ожидания 1+ минуты")


def run_all_tests():
    """Комплексное тестирование сервиса - запуск всех тестов"""
    logger.info("🚀 Запуск базовых тестов...")
    test_base_endpoint()
    test_shorten_link()
    test_custom_link()
    test_redirect()
    test_link_stats()
    test_link_search()
    test_link_with_expiry()
    
    logger.info("\n🚀 Запуск тестов с авторизацией...")
    try:
        auth_headers = register_and_login()
        test_create_project(auth_headers)
        test_get_projects(auth_headers)
        test_update_project(auth_headers)
        test_link_with_project(auth_headers)
    except Exception as e:
        logger.error(f"❌ Ошибка в тестах с авторизацией: {str(e)}", exc_info=True)
    
    logger.info("\n✅ Все тесты завершены!")


if __name__ == "__main__":
    run_all_tests() 
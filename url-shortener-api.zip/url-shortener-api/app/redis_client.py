import os
import redis
from dotenv import load_dotenv

import redis
import logging

# Настроим логирование
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    redis_url = "redis://redis:6379/0"
    r = redis.Redis.from_url(redis_url)
    if r.ping():
        logger.info("Соединение с Redis установлено успешно.")
    else:
        logger.error("Не удалось подключиться к Redis.")
except Exception as e:
    logger.error(f"Ошибка при подключении к Redis: {e}")

load_dotenv()

REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379/0")

redis_client = redis.from_url(REDIS_URL) 
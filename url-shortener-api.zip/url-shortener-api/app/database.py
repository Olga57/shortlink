import os
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

import logging
from sqlalchemy import create_engine
from sqlalchemy.exc import OperationalError

# Настроим логирование
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


try:
    DATABASE_URL = "postgresql://postgres:postgres@postgres:5432/url_shortener"
    engine = create_engine(DATABASE_URL)
    connection = engine.connect()
    logger.info("Подключение к базе данных PostgreSQL установлено.")
except OperationalError as e:
    logger.error(f"Ошибка при подключении к PostgreSQL: {e}")

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@postgres:5432/url_shortener")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close() 
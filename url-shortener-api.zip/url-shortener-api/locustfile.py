
from locust import HttpUser, task, between
import random

class URLShortenerUser(HttpUser):
    wait_time = between(1, 5)  # Время ожидания между запросами от 1 до 5 секунд

    # Тестирование массового создания коротких ссылок
    @task(3)
    def create_link(self):
        # Случайный URL для создания
        original_url = f"https://example.com/{random.randint(1000, 9999)}"
        custom_alias = f"short{random.randint(1000, 9999)}"
        
        response = self.client.post("/links/shorten", json={
            "original_url": original_url,
            "custom_alias": custom_alias
        })
        
        if response.status_code == 200:
            print(f"Создана ссылка: {custom_alias} -> {original_url}")
        else:
            print(f"Ошибка при создании ссылки: {response.status_code}")

    # Тестирование перенаправления по короткому коду
    @task(1)
    def redirect_link(self):
        # Случайный короткий код для редиректа
        short_code = f"short{random.randint(1000, 9999)}"
        
        response = self.client.get(f"/{short_code}")
        
        if response.status_code == 307:
            print(f"Перенаправление на {response.headers['Location']}")
        else:
            print(f"Ошибка редиректа: {response.status_code}")

    # Тестирование создания проекта
    @task(2)
    def create_project(self):
        project_name = f"Project {random.randint(1000, 9999)}"
        project_description = "Automated project for testing"
        
        response = self.client.post("/projects/", json={
            "name": project_name,
            "description": project_description
        })
        
        if response.status_code == 200:
            print(f"Проект создан: {project_name}")
        else:
            print(f"Ошибка при создании проекта: {response.status_code}")

    # Тестирование удаления проекта
    @task(1)
    def delete_project(self):
        project_id = random.randint(1, 100)  # Пример случайного ID проекта для удаления
        
        response = self.client.delete(f"/projects/{project_id}")
        
        if response.status_code == 204:
            print(f"Проект {project_id} удален")
        else:
            print(f"Ошибка при удалении проекта: {response.status_code}")

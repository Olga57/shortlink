#!/bin/bash

echo "✅ Установка зависимостей..."
pip install -r requirements.txt
pip install pytest pytest-mock coverage httpx locust

echo "🚀 Запуск юнит-тестов с покрытием..."
coverage run -m pytest -s tests/unit

# Добавлено: запуск функциональных тестов с покрытием
#echo "🚀 Запуск функциональных тестов с покрытием..."
#coverage run -m pytest -s tests/functional_tests

# Добавлено: запуск нагрузочных тестов с Locust
#echo "🚀 Запуск нагрузочных тестов с Locust..."
#locust -f locustfile.py

# Вывод результатов тестов
#pytest -v tests/functional_tests/

echo "📊 Текстовый отчет о покрытии:"
coverage report -m

echo "🧾 Генерация HTML-отчета..."
coverage html

echo "✅ Готово! Откройте файл htmlcov/index.html в браузере для просмотра."
